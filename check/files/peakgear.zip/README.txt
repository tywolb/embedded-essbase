PeakGear Essbase and AI Lakehouse lab package
October 2026

FILES
peakgear_sales.xlsx            Prepared tabular workbook for Essbase cube import
store_sales_transactions.csv   Original transaction detail for AI Lakehouse
products.csv                   Original product lookup for AI Lakehouse
store_locations.csv            Original store lookup for AI Lakehouse
store_inventory.csv            Original inventory snapshot for optional exercises

ESSBASE IMPORT
1. Extract this ZIP file.
2. In the Essbase web interface, open Applications and select Import.
3. Select File Browser and choose peakgear_sales.xlsx.
4. Accept or enter application name peakgear_sales and cube name Sales.
5. Start the import and check the resulting job status.
6. Open the Sales cube to explore Time, Store, Product, and Measures.

The workbook is an Essbase tabular-data import file. It uses Oracle's
forced-designation column headers to create the cube and load data in one
import. It is not an Essbase application workbook with Essbase.Cube and
Dim.* worksheets.

DATA AND MAPPING
The 80,001 source transaction lines are grouped by month, store, and SKU
into 21,216 cube rows. The source covers 2021-2025, 200 products, and
6 stores. Source CSVs are unchanged. The cube's source measure totals are:
  Units: 102,860
  Sales: 9,786,677.73

Cube member mapping:
  Time.Year        FY2021 through FY2025
  Year.Quarter     YYYY-Qn, derived from the transaction timestamp
  Quarter.Month    YYYY-MM, derived from the transaction timestamp
  Store.City       City parsed from store_locations.location
  City.StoreID     Store_001 through Store_006, mapped from store_id 1-6
  Product.Category Source category, except N/A and null become UNCATEGORIZED
  Category.SKU     products.sku, joined by product_id
  Measures.Units   Sum of qty_sold
  Measures.Sales   Sum of total_sale_amount

EXAMPLE CELL FOR LAB VALIDATION
  FY2021 > 2021-Q1 > 2021-01
  Austin > Store_004
  ACTIVEWEAR > SKU-100002
  Units: 30
  Sales: 1,448.55

VALIDATION STATUS
The Excel file was reopened and checked for its sheet, typed columns,
21,216 rows, and source measure totals. This package has not yet been
imported into a live Essbase instance; run a pilot import before publishing
the LiveLab download link.

Oracle reference:
https://docs.oracle.com/en/database/other-databases/essbase/21/esscd/create-and-update-cube-tabular-data.html
